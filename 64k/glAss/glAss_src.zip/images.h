//
// glAss images
//

#ifndef _IMAGES_H_
#define _IMAGES_H_

extern "C" {

#define GIF_FLARE 102
	extern char gif_flare;
#define GIF_PSIKORP2 103
	extern char gif_psikorp2;
//#define GIF_FLOWER 104
//	extern char gif_flower;
#define GIF_GRID 105
	extern char gif_grid;
#define GIF_FONT 106
	extern char gif_font;
//#define GIF_PSIBAND 108
//	extern char gif_psiband;
#define GIF_ROST 109
	extern char gif_rost;
//#define GIF_LANDSCAPE 110
//	extern char gif_landscape;
#define GIF_CLOUDS 111
	extern char gif_clouds;
#define GIF_PSIKORP3 112
	extern char gif_psikorp3;
#define GIF_TITLE 113
	extern char gif_title;
//#define GIF_FULL 114
//	extern char gif_full;
//#define GIF_TWISTER 115
//	extern char gif_twister;
//#define GIF_SYMBOLER 116
//	extern char gif_symboler;
#define GIF_TWISTER2 117
	extern char gif_twister2;
//#define GIF_FACES 118
//	extern char gif_faces;
//#define GIF_KROM 119
//	extern char gif_krom;
#define GIF_GREEN 120
	extern char gif_green;
#define GIF_SILU 121
	extern char gif_silu;
#define GIF_NAMES 122
	extern char gif_names;
#define GIF_PSIKORP4 123
	extern char gif_psikorp4;

	extern char intromusic; // duh! not a picture
}

#endif
