// images

//extern "C" {

//extern char gif_hippy1;
//extern char gif_hippy2;

extern char gif_grid;
extern char gif_onesph;
extern char gif_font;

extern char gif_face1;
extern char gif_face2;
extern char gif_face3;
extern char gif_face4;

extern char gif_fullscreen;

extern char gif_pic;
extern char gif_hands;

extern char gif_pixlad;

//}
