// parts

void p_bpl_init();
void p_bpl_run();
void p_bpl_kill();

void p_raster_init();
void p_raster_run();
void p_raster_kill();

void p_intro_init();
void p_intro_run();
void p_intro_kill();

void p_tunnel_init();
void p_tunnel_run();
void p_tunnel_kill();

void p_lines_init();
void p_lines_kill();
void p_lines_run();

void p_lines2_init();
void p_lines2_kill();
void p_lines2_run();

void p_pic_init();
void p_pic_kill();
void p_pic_run();

void p_blobs_init();
void p_blobs_kill();
void p_blobs_run();

void p_pic2_init();
void p_pic2_kill();
void p_pic2_run();
